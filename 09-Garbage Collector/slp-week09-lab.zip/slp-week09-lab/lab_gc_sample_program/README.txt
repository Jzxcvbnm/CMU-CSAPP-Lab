All garbage collector sample programs are implemented in "BUSY MODE", the higher 
performance version "LAZY MODE" doesn't get implemented.

The difference between "MIGRATING MODE" and none is whether to migrate free segments 
together when collecting garbage.

All program can be used to show how necessary the garbage collection is.
